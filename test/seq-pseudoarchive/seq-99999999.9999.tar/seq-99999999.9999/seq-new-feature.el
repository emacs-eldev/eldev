(provide 'seq-new-feature)
