;;; seq.el --- Fake upgrade for built-in package `seq'  -*- lexical-binding: t -*-

;; Version: 99999999.9999
;; Homepage: https://example.com/

;;; Code:

(require 'seq-new-feature)

(provide 'seq)

;;; seq.el ends here
