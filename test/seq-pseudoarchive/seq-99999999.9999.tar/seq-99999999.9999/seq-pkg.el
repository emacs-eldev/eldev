; -*- no-byte-compile: t -*-
(define-package "seq" "99999999.9999" "Fake upgrade for built-in package `seq'" nil :url "https://example.com/")
