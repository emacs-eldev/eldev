; -*- no-byte-compile: t -*-
(define-package "project-i" "1.0" "Test project with autoload cookies in multiple files and both ERT and Buttercup tests" nil :url "https://example.com/")
