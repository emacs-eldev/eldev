;;; dependency-e.el --- Multifile dependency test package E  -*- lexical-binding: t -*-

;; Version: 1.0

(require 'dependency-e-advanced)

(defun dependency-e-hello ()
  "Hello")

(defun dependency-e-stable ()
  t)

(provide 'dependency-e)

;;; dependency-e.el ends here
