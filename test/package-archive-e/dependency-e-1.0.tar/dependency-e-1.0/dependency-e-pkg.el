; -*- no-byte-compile: t -*-
(define-package "dependency-e" "1.0" "Multifile dependency test package E" nil)
